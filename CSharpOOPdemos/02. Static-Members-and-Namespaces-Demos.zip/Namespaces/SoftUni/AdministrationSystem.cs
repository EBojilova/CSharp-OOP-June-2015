﻿namespace SoftUni
{
    public class AdministrationSystem
    {
        public static void Main()
        {
            // ...
        }
    }
}
